from .trainers import register, trainers_dict
from . import base_trainer
from . import imgrec_trainer
from . import nvs_trainer
