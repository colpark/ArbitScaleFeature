from .datasets import register, make
from . import imgrec_dataset, celeba, imagenette
from . import learnit_shapenet
